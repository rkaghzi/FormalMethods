"""
Feature Model Analysis Tool — GUI (Tkinter)
FAST NUCES — Formal Methods Project
Part 1: Feature Model Analysis
Part 2: Feature-to-Code Impact Analysis
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from fm_core import FeatureModelParser, LogicTranslator, SATValidator, MWPGenerator, Feature
from typing import Optional
import threading, os

BG        = "#0f1117"
PANEL     = "#1a1d27"
BORDER    = "#2a2d3a"
ACCENT    = "#6c8fff"
ACCENT2   = "#a78bfa"
GREEN     = "#4ade80"
RED       = "#f87171"
YELLOW    = "#fbbf24"
TEXT      = "#e2e8f0"
TEXT_DIM  = "#64748b"
FONT_MAIN = ("Consolas", 10)

class FeatureModelApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Feature Model Analysis Tool  —  FAST NUCES | Formal Methods")
        self.geometry("1360x840")
        self.configure(bg=BG)
        self.minsize(1100, 700)
        self.parser = None; self.translator = None
        self.validator = None; self.mwp_gen = None
        self.check_vars = {}; self.check_widgets = {}
        self._suppress = False
        self.p2_loader = None
        self.p2_file_deps = []; self.p2_feature_deps = []; self.p2_inconsistencies = []
        self._build_ui()

    def _build_ui(self):
        self._style()
        hdr = tk.Frame(self, bg=PANEL, height=52); hdr.pack(fill="x"); hdr.pack_propagate(False)
        tk.Label(hdr, text="⬡  Feature Model Analysis Tool", bg=PANEL, fg=ACCENT, font=("Consolas",15,"bold")).pack(side="left", padx=20, pady=10)
        tk.Label(hdr, text="FAST NUCES — Formal Methods", bg=PANEL, fg=TEXT_DIM, font=FONT_MAIN).pack(side="right", padx=20)
        tk.Frame(self, bg=BORDER, height=1).pack(fill="x")
        s = ttk.Style(); s.configure("TNotebook", background=BG, borderwidth=0)
        s.configure("TNotebook.Tab", background=PANEL, foreground=TEXT_DIM, font=("Consolas",11,"bold"), padding=[18,8])
        s.map("TNotebook.Tab", background=[("selected",BG)], foreground=[("selected",ACCENT)])
        self.nb = ttk.Notebook(self); self.nb.pack(fill="both", expand=True)
        t1 = tk.Frame(self.nb, bg=BG); t2 = tk.Frame(self.nb, bg=BG)
        self.nb.add(t1, text="  Part 1 — Feature Model Analysis  ")
        self.nb.add(t2, text="  Part 2 — Code Impact Analysis  ")
        self._build_p1(t1); self._build_p2(t2)
        self.status_var = tk.StringVar(value="Ready — load a feature model XML to begin.")
        tk.Label(self, textvariable=self.status_var, bg=BORDER, fg=TEXT_DIM, font=FONT_MAIN, anchor="w", padx=12, pady=4).pack(fill="x", side="bottom")

    def _build_p1(self, par):
        tb = tk.Frame(par, bg=BG, pady=8); tb.pack(fill="x", padx=16)
        self._btn(tb,"📂  Load XML File",  self._load_file,    ACCENT).pack(side="left",  padx=4)
        self._btn(tb,"📋  Paste XML",       self._paste_xml,    ACCENT2).pack(side="left", padx=4)
        self._btn(tb,"✅  Validate",        self._validate,     GREEN).pack(side="left",   padx=4)
        self._btn(tb,"🔢  Generate MWPs",   self._gen_mwps,     YELLOW).pack(side="left",  padx=4)
        self._btn(tb,"🧹  Clear",           self._clear_all,    RED).pack(side="right",    padx=4)
        pane = tk.PanedWindow(par, orient="horizontal", bg=BG, sashwidth=6, bd=0)
        pane.pack(fill="both", expand=True, padx=10, pady=4)
        # Left
        L = tk.Frame(pane, bg=PANEL); pane.add(L, minsize=280)
        self._sec(L,"FEATURE TREE  [●=mandatory  ○=optional  ⊕=XOR  ⊎=OR]")
        wrap = tk.Frame(L, bg=PANEL); wrap.pack(fill="both", expand=True, padx=8, pady=4)
        self.tree_canvas = tk.Canvas(wrap, bg=PANEL, highlightthickness=0)
        sb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree_canvas.yview)
        self.tree_canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y"); self.tree_canvas.pack(side="left", fill="both", expand=True)
        self.tree_inner = tk.Frame(self.tree_canvas, bg=PANEL)
        win = self.tree_canvas.create_window((0,0), window=self.tree_inner, anchor="nw")
        self.tree_inner.bind("<Configure>", lambda e: self.tree_canvas.configure(scrollregion=self.tree_canvas.bbox("all")))
        self.tree_canvas.bind("<Configure>", lambda e: self.tree_canvas.itemconfig(win, width=e.width))
        # Mid
        M = tk.Frame(pane, bg=PANEL); pane.add(M, minsize=320)
        self._sec(M,"PROPOSITIONAL LOGIC RULES"); self.logic_text = self._tb(M, 13)
        self._sec(M,"CROSS-TREE CONSTRAINTS");    self.con_text   = self._tb(M, 5)
        self._sec(M,"VALIDATION RESULT");          self.val_text   = self._tb(M, 8)
        # Right
        R = tk.Frame(pane, bg=PANEL); pane.add(R, minsize=280)
        self._sec(R,"MINIMUM WORKING PRODUCTS"); self.mwp_text = self._tb(R, expand=True)

    def _build_p2(self, par):
        tb = tk.Frame(par, bg=BG, pady=8); tb.pack(fill="x", padx=16)
        self._btn(tb,"📁  Load Codebase Folder", self._p2_load,    ACCENT).pack(side="left",  padx=4)
        self._btn(tb,"🔍  Extract Dependencies",  self._p2_extract, GREEN).pack(side="left",   padx=4)
        self._btn(tb,"⚠  Detect Inconsistencies",self._p2_detect,  RED).pack(side="left",     padx=4)
        self._btn(tb,"🎯  Impact Analysis",       self._p2_impact,  YELLOW).pack(side="left",  padx=4)
        pane = tk.PanedWindow(par, orient="horizontal", bg=BG, sashwidth=6, bd=0)
        pane.pack(fill="both", expand=True, padx=10, pady=4)
        # Left
        L = tk.Frame(pane, bg=PANEL); pane.add(L, minsize=300)
        self._sec(L,"CODEBASE STRUCTURE");      self.p2_struct   = self._tb(L, 10)
        self._sec(L,"FEATURE → FILE MAPPING");  self.p2_mapping  = self._tb(L, expand=True)
        # Mid
        M = tk.Frame(pane, bg=PANEL); pane.add(M, minsize=340)
        self._sec(M,"FILE-LEVEL DEPENDENCIES");    self.p2_fdeps  = self._tb(M, 14)
        self._sec(M,"FEATURE-LEVEL DEPENDENCIES"); self.p2_featdeps = self._tb(M, expand=True)
        # Right
        R = tk.Frame(pane, bg=PANEL); pane.add(R, minsize=320)
        self._sec(R,"INCONSISTENCY DETECTION"); self.p2_incons = self._tb(R, 20)
        self._sec(R,"IMPACT ANALYSIS RESULT"); self.p2_impact_t = self._tb(R, expand=True)

    # ── Part 1 Actions ──────────────────────

    def _load_file(self):
        path = filedialog.askopenfilename(title="Open XML", filetypes=[("XML","*.xml"),("All","*.*")])
        if path:
            try:
                with open(path) as f: self._process_xml(f.read())
                self.status_var.set(f"Loaded: {path}")
            except Exception as e: messagebox.showerror("Error", str(e))

    def _paste_xml(self):
        dlg = tk.Toplevel(self); dlg.title("Paste XML"); dlg.configure(bg=BG); dlg.geometry("680x500"); dlg.transient(self)
        tk.Label(dlg, text="Paste feature model XML:", bg=BG, fg=TEXT, font=FONT_MAIN).pack(padx=12, pady=8, anchor="w")
        t = scrolledtext.ScrolledText(dlg, bg="#0d0f18", fg=TEXT, font=FONT_MAIN, relief="flat", height=20, padx=8, pady=8)
        t.pack(fill="both", expand=True, padx=12)
        def go():
            xml = t.get("1.0","end").strip()
            if xml:
                try: self._process_xml(xml); dlg.destroy(); self.status_var.set("XML loaded from paste.")
                except Exception as e: messagebox.showerror("Error", str(e))
        self._btn(dlg,"▶  Parse XML", go, GREEN).pack(pady=10)

    def _process_xml(self, xml):
        self.parser = FeatureModelParser().parse(xml)
        self.translator = LogicTranslator(self.parser)
        self.validator = SATValidator(self.translator)
        self.mwp_gen = MWPGenerator(self.parser, self.validator)
        self._build_tree(); self._pop_logic(); self._pop_cons()
        self._clr(self.val_text); self._clr(self.mwp_text)

    def _build_tree(self):
        for w in self.tree_inner.winfo_children(): w.destroy()
        self.check_vars.clear(); self.check_widgets.clear()
        if self.parser and self.parser.root:
            self._render(self.parser.root, self.tree_inner, 0)

    def _render(self, feat, parent_w, depth):
        row = tk.Frame(parent_w, bg=PANEL); row.pack(fill="x", padx=(depth*18,0), pady=1)
        if feat.parent is None:           icon, col = "◈", ACCENT
        elif feat.mandatory:              icon, col = "●", GREEN
        elif feat.group_type == "xor":    icon, col = "⊕", YELLOW
        elif feat.group_type == "or":     icon, col = "⊎", ACCENT2
        else:                             icon, col = "○", TEXT_DIM
        tk.Label(row, text=icon, bg=PANEL, fg=col, font=("Consolas",10)).pack(side="left", padx=(2,4))
        var = tk.BooleanVar(value=(feat.parent is None or feat.mandatory))
        self.check_vars[feat.name] = var
        cb = ttk.Checkbutton(row, text=feat.name, variable=var,
                              state="disabled" if feat.parent is None else "normal",
                              command=lambda f=feat: self._on_check(f))
        cb.pack(side="left"); self.check_widgets[feat.name] = cb
        tags = []
        if feat.parent is None: tags.append("root")
        if feat.mandatory: tags.append("mandatory")
        if feat.group_type: tags.append(feat.group_type.upper())
        if tags: tk.Label(row, text=f"[{' | '.join(tags)}]", bg=PANEL, fg=TEXT_DIM, font=("Consolas",8)).pack(side="left", padx=4)
        for ch in feat.children:
            if ch.group_type is None: self._render(ch, parent_w, depth+1)
        for g in (self.parser.groups if self.parser else []):
            if g["parent"] is feat:
                gtype = g["type"].upper(); gclr = YELLOW if gtype=="XOR" else ACCENT2
                gf = tk.Frame(parent_w, bg=PANEL, highlightthickness=1, highlightbackground=gclr)
                gf.pack(fill="x", padx=(depth*18+18,4), pady=3)
                tk.Label(gf, text=f" {gtype} GROUP ", bg=gclr, fg=BG, font=("Consolas",8,"bold")).pack(anchor="w")
                for m in g["members"]: self._render(m, gf, 0)

    def _on_check(self, feat):
        if self._suppress: return
        self._suppress = True
        sel = self.check_vars[feat.name].get()
        if sel and feat.group_type == "xor":
            for sib in feat.group_members:
                self.check_vars[sib.name].set(False); self._desel(sib)
        if sel:
            import re
            for c in (self.parser.constraints if self.parser else []):
                m = re.match(r"(\w+)\s*→\s*(\w+)", c.propositional or "")
                if m and m.group(1) == feat.name and m.group(2) in self.check_vars:
                    self.check_vars[m.group(2)].set(True)
        if not sel and feat.mandatory:
            self.check_vars[feat.name].set(True)
            self._show(self.val_text, f"⚠  Cannot deselect mandatory feature: {feat.name}\n", RED)
            self._suppress = False; return
        if not sel: self._desel(feat)
        self._suppress = False; self._quick_check()

    def _desel(self, feat):
        for ch in feat.children:
            if ch.name in self.check_vars: self.check_vars[ch.name].set(False); self._desel(ch)
        for g in (self.parser.groups if self.parser else []):
            if g["parent"] is feat:
                for m in g["members"]: self.check_vars[m.name].set(False); self._desel(m)

    def _quick_check(self):
        if not self.validator: return
        sel = {n for n,v in self.check_vars.items() if v.get()}
        ok, msg = self.validator.validate(sel)
        self._show(self.val_text, msg+"\n", GREEN if ok else RED)

    def _validate(self):
        if not self.validator: messagebox.showwarning("No Model","Load XML first."); return
        sel = {n for n,v in self.check_vars.items() if v.get()}
        ok, msg = self.validator.validate(sel)
        detail = "\n\nSelected: " + ", ".join(sorted(sel))
        self._show(self.val_text, msg+detail+"\n", GREEN if ok else RED)

    def _gen_mwps(self):
        if not self.mwp_gen: messagebox.showwarning("No Model","Load XML first."); return
        self.status_var.set("Computing MWPs…"); self._show(self.mwp_text,"⏳ Computing…\n",YELLOW)
        def run(): mwps = self.mwp_gen.generate(); self.after(0, lambda: self._show_mwps(mwps))
        threading.Thread(target=run, daemon=True).start()

    def _show_mwps(self, mwps):
        if not mwps: self._show(self.mwp_text,"No MWPs found.\n",RED); return
        lines = [f"Found {len(mwps)} Minimum Working Product(s):\n","─"*44]
        for i,m in enumerate(mwps,1): lines.append(f"\nMWP #{i}  ({len(m)} features):\n  " + ",  ".join(sorted(m)))
        self._show(self.mwp_text, "\n".join(lines), GREEN)
        self.status_var.set(f"MWP complete — {len(mwps)} product(s).")

    def _pop_logic(self):
        if not self.translator: return
        lines = ["Propositional Logic Rules:\n","─"*44, self.translator.get_rules_text(),
                 "\n\nVariable Map (CNF encoding):"]
        for name,var in self.translator.var_map.items(): lines.append(f"  x{var:02d}  =  {name}")
        self._show(self.logic_text, "\n".join(lines), TEXT)

    def _pop_cons(self):
        if not self.parser: return
        if not self.parser.constraints: self._show(self.con_text,"No constraints.\n",TEXT_DIM); return
        lines = []
        for i,c in enumerate(self.parser.constraints,1):
            lines.append(f"Constraint {i}:")
            if c.english: lines.append(f"  English : {c.english}")
            if c.boolean_expr: lines.append(f"  Boolean : {c.boolean_expr}")
            if c.propositional: lines.append(f"  Logic   : {c.propositional}")
            lines.append("")
        self._show(self.con_text, "\n".join(lines), ACCENT)

    def _clear_all(self):
        self.parser = self.translator = self.validator = self.mwp_gen = None
        for w in self.tree_inner.winfo_children(): w.destroy()
        self.check_vars.clear(); self.check_widgets.clear()
        for t in [self.logic_text, self.con_text, self.val_text, self.mwp_text]: self._clr(t)
        self.status_var.set("Cleared.")

    # ── Part 2 Actions ──────────────────────

    def _p2_load(self):
        from part2_core import CodebaseLoader, FEATURE_FILE_MAPPING, MAPPING_JUSTIFICATIONS
        path = filedialog.askdirectory(title="Select Codebase Folder")
        if not path: return
        self.p2_loader = CodebaseLoader(); self.p2_loader.load_folder(path)
        n = len(self.p2_loader.files)
        if n == 0: messagebox.showwarning("Empty","No source files found."); return
        lines = [f"Root: {path}", f"Files: {n}", "─"*40]
        for f in sorted(self.p2_loader.files):
            lines.append("  "*f.count("/") + "📄 " + f)
        self._show(self.p2_struct, "\n".join(lines), TEXT)
        mlines = ["Feature  →  File(s)\n","─"*60]
        for feat,files in FEATURE_FILE_MAPPING.items():
            just = MAPPING_JUSTIFICATIONS.get(feat,"")
            mlines.append(f"\n{feat}:")
            for f in files: mlines.append(f"  📄 {f}")
            mlines.append(f"  ↳ {just}")
        self._show(self.p2_mapping, "\n".join(mlines), ACCENT)
        self.status_var.set(f"Codebase loaded: {n} files.")

    def _p2_extract(self):
        if not self.p2_loader: messagebox.showwarning("No Codebase","Load a folder first."); return
        from part2_core import DependencyExtractor, FeatureDependencyDeriver
        self.p2_file_deps = DependencyExtractor(self.p2_loader).extract()
        lines = [f"File Dependencies Found: {len(self.p2_file_deps)}\n","─"*60]
        for d in self.p2_file_deps:
            lines.append(f"\n  {d.source}  →  {d.target}")
            lines.append(f"    [{d.line_number}] {d.evidence}")
        self._show(self.p2_fdeps, "\n".join(lines), TEXT)
        self.p2_feature_deps = FeatureDependencyDeriver(self.p2_file_deps).derive()
        flines = [f"Feature-Level Dependencies: {len(self.p2_feature_deps)}\n","─"*60,
                  "(Inferred: feature→file mapping + file→file deps)\n"]
        for fd in self.p2_feature_deps:
            flines.append(f"  {fd.source_feature}  →  {fd.target_feature}")
            flines.append(f"    via {fd.via_source_file} → {fd.via_target_file}")
            flines.append(f"    {fd.evidence}\n")
        self._show(self.p2_featdeps, "\n".join(flines), ACCENT2)
        self.status_var.set(f"{len(self.p2_file_deps)} file deps, {len(self.p2_feature_deps)} feature deps.")

    def _p2_detect(self):
        if not self.p2_feature_deps: messagebox.showwarning("Extract First","Run extraction first."); return
        if not self.parser: messagebox.showwarning("No FM","Load a feature model in Part 1 first."); return
        from part2_core import InconsistencyDetector
        self.p2_inconsistencies = InconsistencyDetector(self.p2_feature_deps, self.parser).detect()
        lines = [f"Inconsistencies Detected: {len(self.p2_inconsistencies)}\n","═"*60]
        KINDS = {"hidden":"⚠  HIDDEN DEPENDENCY","missing":"⚠  MISSING CONSTRAINT","incorrect":"⚠  INCORRECT CONSTRAINT"}
        for i,inc in enumerate(self.p2_inconsistencies,1):
            lines.append(f"\n[{i}] {KINDS.get(inc.kind, inc.kind.upper())}")
            lines.append(f"    {inc.source_feature}  →  {inc.target_feature}")
            lines.append(f"\n    Description:\n    {inc.description}")
            lines.append(f"\n    Evidence:")
            for ln in inc.evidence.splitlines(): lines.append(f"      {ln}")
            lines.append(f"\n    Resolution:\n      {inc.resolution}")
            lines.append("\n"+"─"*60)
        self._show(self.p2_incons, "\n".join(lines), RED)
        self.status_var.set(f"Detection complete — {len(self.p2_inconsistencies)} inconsistency(s) found.")

    def _p2_impact(self):
        if not self.p2_file_deps: messagebox.showwarning("Extract First","Run extraction first."); return
        if not self.check_vars: messagebox.showwarning("No Selection","Select features in Part 1 first."); return
        from part2_core import ImpactAnalyser
        sel = {n for n,v in self.check_vars.items() if v.get()}
        res = ImpactAnalyser(self.p2_file_deps).analyse(sel)
        lines = ["Impact Analysis\n","═"*50,
                 f"\nSelected Features ({len(res['selected_features'])}):",
                 *[f"  ✔  {f}" for f in res["selected_features"]],
                 f"\nDirect Files ({len(res['direct_files'])}):",
                 "  (Directly implement selected features)",
                 *[f"  📄 {f}" for f in res["direct_files"]],
                 f"\nIndirect Dependencies ({len(res['indirect_files'])}):",
                 "  (Transitively required at runtime)",
                 *[f"  ↳  {f}" for f in res["indirect_files"]],
                 f"\nTotal Impacted: {len(res['all_impacted'])} file(s)"]
        self._show(self.p2_impact_t, "\n".join(lines), GREEN)
        self.status_var.set(f"Impact: {len(res['all_impacted'])} files affected.")

    # ── UI Helpers ───────────────────────────

    def _style(self):
        s = ttk.Style(self); s.theme_use("clam")
        s.configure("TCheckbutton", background=PANEL, foreground=TEXT, font=FONT_MAIN, focuscolor=PANEL)
        s.map("TCheckbutton", foreground=[("active",ACCENT),("disabled",TEXT_DIM)], background=[("active",PANEL)])
        s.configure("Vertical.TScrollbar", background=BORDER, troughcolor=PANEL, bordercolor=PANEL, arrowcolor=TEXT_DIM)

    def _btn(self, par, text, cmd, color):
        return tk.Button(par, text=text, command=cmd, bg=PANEL, fg=color, font=FONT_MAIN,
                         relief="flat", padx=12, pady=5, activebackground=BORDER,
                         activeforeground=color, cursor="hand2", bd=1,
                         highlightthickness=1, highlightbackground=color)

    def _sec(self, par, text):
        tk.Frame(par, bg=BG, height=1).pack(fill="x", pady=(6,0))
        tk.Label(par, text=f"  {text}", bg=BG, fg=ACCENT2, font=("Consolas",9,"bold"), anchor="w").pack(fill="x")
        tk.Frame(par, bg=BORDER, height=1).pack(fill="x")

    def _tb(self, par, height=10, expand=False):
        t = scrolledtext.ScrolledText(par, bg="#0d0f18", fg=TEXT, font=FONT_MAIN, relief="flat",
                                       height=height, padx=8, pady=8, insertbackground=ACCENT,
                                       selectbackground=ACCENT, wrap="word", state="disabled", bd=0)
        t.pack(fill="both", expand=expand, padx=8, pady=4); return t

    def _show(self, w, text, color=TEXT):
        w.config(state="normal"); w.delete("1.0","end"); w.insert("end", text)
        w.tag_add("c","1.0","end"); w.tag_config("c", foreground=color); w.config(state="disabled")

    def _clr(self, w):
        w.config(state="normal"); w.delete("1.0","end"); w.config(state="disabled")

if __name__ == "__main__":
    FeatureModelApp().mainloop()
