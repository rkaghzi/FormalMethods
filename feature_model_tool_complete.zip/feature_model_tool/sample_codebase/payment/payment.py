# payment/payment.py
# Payment processing: CreditCard and Discount

import auth.auth as auth
import shared.database as database
import location.location as location   # ← INCONSISTENCY: Payment imports Location
                                        #   but the feature model does NOT declare
                                        #   Payment → Location as a dependency.

def charge_credit_card(token, amount, card_number):
    """Process a credit card payment."""
    user = auth.require_auth(token)

    # BUG / hidden dependency: developer added geo-fraud check that calls location
    user_loc = location.get_user_location(user)
    if user_loc is None:
        user_loc = location.get_best_location()

    # Simulate fraud check using location (hidden coupling!)
    if user_loc and user_loc.get("method") == "unknown":
        raise ValueError("Location could not be verified for fraud check.")

    database.put("payments", f"{user}_cc", {
        "amount": amount,
        "card": card_number[-4:],
        "status": "approved",
        "location": user_loc
    })
    return {"status": "approved", "amount": amount}

def apply_discount(token, cart_total, discount_code):
    """Apply a discount code to a cart total."""
    auth.require_auth(token)
    discounts = {"SAVE10": 0.10, "SAVE20": 0.20, "HALF": 0.50}
    rate = discounts.get(discount_code.upper(), 0)
    if rate == 0:
        return {"status": "invalid_code", "total": cart_total}
    new_total = cart_total * (1 - rate)
    return {"status": "applied", "discount": rate, "total": new_total}

def get_payment_history(token):
    """Return payment history for authenticated user."""
    user = auth.require_auth(token)
    return database.get("payments", f"{user}_cc")
