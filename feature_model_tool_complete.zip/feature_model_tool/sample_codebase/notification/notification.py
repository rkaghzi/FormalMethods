# notification/notification.py
# Notification feature: SMS and Call-based alerts

import shared.config as config
import shared.database as database

def send_sms(phone_number, message):
    """Send an SMS notification."""
    if not config.FEATURE_NOTIFICATION:
        return False
    # In real app: call SMS gateway API
    print(f"[SMS] To: {phone_number} | Msg: {message}")
    database.put("sms_log", phone_number, {"msg": message, "sent": True})
    return True

def send_call_alert(phone_number, message):
    """Trigger an automated call alert."""
    if not config.FEATURE_NOTIFICATION:
        return False
    # In real app: call telephony API
    print(f"[CALL] To: {phone_number} | Msg: {message}")
    return True

def notify_user(user_id, message, method="sms"):
    user = database.get("users", user_id)
    if not user:
        return False
    phone = user.get("phone", "")
    if method == "sms":
        return send_sms(phone, message)
    elif method == "call":
        return send_call_alert(phone, message)
    return False
