# app_main.py
# Application entry point — wires all features together

import auth.auth as auth
import catalog.catalog as catalog
import catalog.filter as filter_mod
import payment.checkout as checkout
import notification.order_alerts as alerts
import shared.logger as logger

def bootstrap():
    """Seed demo data."""
    from shared import database
    database.put("users", "alice", {"password": "pass123", "phone": "0300-0000001"})
    catalog.add_product("p1", "Umbrella",    500, "accessories", ["rainy", "local"])
    catalog.add_product("p2", "Sunglasses",  900, "accessories", ["sunny"])
    catalog.add_product("p3", "Laptop Bag", 2500, "bags",        ["local"], )
    logger.info("main", "Bootstrap complete.")

def demo_run():
    bootstrap()
    token = auth.login("alice", "pass123")
    logger.info("main", f"Logged in: {token}")

    products = filter_mod.filter_by_discount(5)
    logger.info("main", f"Discounted products: {products}")

    checkout.add_to_cart(token, "p1")
    result = checkout.checkout(token, "4111111111111111")
    logger.info("main", f"Checkout result: {result}")

    alerts.notify_order_confirmed("alice", result["order_total"])

if __name__ == "__main__":
    demo_run()
