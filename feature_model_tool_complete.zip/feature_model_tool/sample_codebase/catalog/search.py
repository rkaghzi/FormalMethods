# catalog/search.py
# Full-text search over the catalog

import catalog.catalog as catalog

def search_products(query):
    """Search products by name or tags (case-insensitive)."""
    query_lower = query.lower()
    results = {}
    for pid, product in catalog.get_all_products().items():
        name_match = query_lower in product.get("name", "").lower()
        tag_match = any(query_lower in t.lower() for t in product.get("tags", []))
        if name_match or tag_match:
            results[pid] = product
    return results

def get_by_category(category):
    products = catalog.get_all_products()
    return {pid: p for pid, p in products.items()
            if p.get("category", "").lower() == category.lower()}
