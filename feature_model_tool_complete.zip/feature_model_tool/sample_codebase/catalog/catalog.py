# catalog/catalog.py
# Core product catalog management

import shared.database as database

def get_all_products():
    """Return all products from the catalog."""
    return database.all_rows("products")

def get_product(product_id):
    return database.get("products", product_id)

def add_product(product_id, name, price, category, tags=None):
    database.put("products", product_id, {
        "name": name,
        "price": price,
        "category": category,
        "tags": tags or []
    })

def remove_product(product_id):
    database.delete("products", product_id)
