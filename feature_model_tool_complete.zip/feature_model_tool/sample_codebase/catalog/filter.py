# catalog/filter.py
# Filtered catalog: ByDiscount, ByWeather, ByLocation

import catalog.catalog as catalog
import location.location as location   # ByLocation filtering requires Location feature

def filter_by_discount(min_discount_pct=10):
    """Return products with a discount >= min_discount_pct."""
    products = catalog.get_all_products()
    return {pid: p for pid, p in products.items()
            if p.get("discount", 0) >= min_discount_pct}

def filter_by_weather(weather_tag):
    """Return products tagged for the current weather (e.g. 'rainy', 'sunny')."""
    products = catalog.get_all_products()
    return {pid: p for pid, p in products.items()
            if weather_tag in p.get("tags", [])}

def filter_by_location(user_id):
    """
    Return products available near the user's location.
    Depends on: location.location — the Location feature must be active.
    """
    user_loc = location.get_user_location(user_id)
    if user_loc is None:
        user_loc = location.get_best_location()
    products = catalog.get_all_products()
    # Simplified: return all products tagged with user's city
    nearby = {}
    for pid, p in products.items():
        if "local" in p.get("tags", []):
            nearby[pid] = p
    return nearby
