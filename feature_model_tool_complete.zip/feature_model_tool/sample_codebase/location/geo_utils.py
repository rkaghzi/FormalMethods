# location/geo_utils.py
# Utility functions for geographic calculations

import math

def haversine_distance(lat1, lon1, lat2, lon2):
    """Calculate distance in km between two GPS coordinates."""
    R = 6371  # Earth's radius in km
    d_lat = math.radians(lat2 - lat1)
    d_lon = math.radians(lon2 - lon1)
    a = (math.sin(d_lat / 2) ** 2 +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
         math.sin(d_lon / 2) ** 2)
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

def is_within_radius(user_loc, store_loc, radius_km=10):
    dist = haversine_distance(
        user_loc["lat"], user_loc["lon"],
        store_loc["lat"], store_loc["lon"]
    )
    return dist <= radius_km
