# shared/config.py
# Application-wide configuration constants

APP_NAME = "ShopApp"
VERSION = "1.0.0"
DEBUG = False

DATABASE_URL = "sqlite:///shopapp.db"
SECRET_KEY = "changeme-in-production"

# Feature flags (runtime toggle)
FEATURE_NOTIFICATION = True
FEATURE_LOCATION = True
FEATURE_DISCOUNT = True
