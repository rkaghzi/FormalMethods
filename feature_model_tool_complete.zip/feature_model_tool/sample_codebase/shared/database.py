# shared/database.py
# Lightweight database abstraction layer

import shared.config as config

_store = {}  # In-memory store (demo)

def get(table, key):
    return _store.get(f"{table}:{key}")

def put(table, key, value):
    _store[f"{table}:{key}"] = value

def delete(table, key):
    _store.pop(f"{table}:{key}", None)

def all_rows(table):
    prefix = f"{table}:"
    return {k[len(prefix):]: v for k, v in _store.items() if k.startswith(prefix)}
