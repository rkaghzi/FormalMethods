# Feature Model Analysis Tool — Part 1
## FAST NUCES | Formal Methods Project

---

## HOW TO RUN (Windows / macOS / Linux)

### Step 1 — Install Python 3.10+
Download from: https://www.python.org/downloads/
Make sure to check "Add Python to PATH" during installation (Windows).

### Step 2 — Install the only dependency
Open Terminal (macOS/Linux) or Command Prompt (Windows), then run:

    pip install python-sat

### Step 3 — Run the tool
Navigate to the project folder and run:

    python app.py

That's it. A dark GUI window will open.

---

## USAGE

1. Click **📂 Load XML File** → select your `feature-model.xml`
   OR click **📋 Paste XML** → paste the XML text directly

2. The tool will instantly:
   - Display the **Feature Tree** (left panel) with checkboxes
   - Show all **Propositional Logic Rules** (middle panel)
   - Show translated **Cross-tree Constraints**

3. **Interact with the Feature Tree**:
   - Mandatory features (●) are auto-selected and cannot be deselected
   - Optional features (○) can be toggled freely
   - XOR groups (⊕): selecting one auto-deselects siblings
   - Cross-tree: selecting ByLocation auto-selects Location

4. Click **✅ Validate Selection** to check if current selection is valid
   - Shows ✅ Valid or ❌ Invalid with specific reasons

5. Click **🔢 Generate MWPs** to compute all Minimum Working Products
   - Results appear in the right panel

---

## FILES

| File              | Purpose                                      |
|-------------------|----------------------------------------------|
| `app.py`          | Main GUI application (Tkinter)               |
| `fm_core.py`      | Core logic: Parser, Translator, SAT, MWP     |
| `feature-model.xml` | Sample feature model XML                  |
| `requirements.txt`  | Python dependencies                        |

---

## WHAT IS IMPLEMENTED

- [x] XML Parsing (Step 2.1)
- [x] Propositional Logic Translation (Step 2.2)
      - Mandatory: Parent → Child
      - Optional: Child → Parent (if selected)
      - XOR: exactly one
      - OR: at least one
      - Cross-tree: ByLocation → Location
- [x] Interactive Feature Selection UI (Step 2.3)
- [x] Dynamic Constraint Checking (Step 2.4)
- [x] SAT Validation via PySAT/Glucose3 (Step 2.5)
- [x] MWP Generation — all 8 minimal products (Step 2.6)
- [x] Visualization — checkbox tree with group display (Step 2.7)
